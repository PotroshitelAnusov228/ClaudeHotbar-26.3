package com.example.squarehotbar;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class HotbarConfigScreen extends Screen {
    private Button stepButton;

    public HotbarConfigScreen() {
        super(Component.literal("Настройка хотбара"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static Component t(String s) {
        return Component.literal(s);
    }

    private void add(String label, int x, int y, int w, Button.OnPress action) {
        this.addRenderableWidget(Button.builder(t(label), action).bounds(x, y, w, 20).build());
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y0 = this.height / 2 - 90;

        // размер
        add("-", cx - 50, y0 + 12, 20, b -> {
            HotbarConfig.cellSize -= HotbarConfig.step;
            HotbarConfig.clamp();
        });
        add("+", cx + 30, y0 + 12, 20, b -> {
            HotbarConfig.cellSize += HotbarConfig.step;
            HotbarConfig.clamp();
        });

        // перемещение
        add("^", cx - 10, y0 + 52, 20, b -> HotbarConfig.offsetY -= HotbarConfig.step);
        add("<", cx - 32, y0 + 74, 20, b -> HotbarConfig.offsetX -= HotbarConfig.step);
        add(">", cx + 12, y0 + 74, 20, b -> HotbarConfig.offsetX += HotbarConfig.step);
        add("v", cx - 10, y0 + 96, 20, b -> HotbarConfig.offsetY += HotbarConfig.step);

        // шаг 1 / 5 / 10 px
        this.stepButton = Button.builder(t(stepLabel()), b -> {
            HotbarConfig.step = HotbarConfig.step == 1 ? 5 : (HotbarConfig.step == 5 ? 10 : 1);
            b.setMessage(t(stepLabel()));
        }).bounds(cx - 60, y0 + 122, 120, 20).build();
        this.addRenderableWidget(this.stepButton);

        add("Сбросить", cx - 60, y0 + 146, 120, b -> HotbarConfig.reset());
        add("Готово", cx - 60, y0 + 170, 120, b -> this.onClose());
    }

    private static String stepLabel() {
        return "Шаг: " + HotbarConfig.step + " px";
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        int cx = this.width / 2;
        int y0 = this.height / 2 - 90;

        g.centeredText(this.font, t("Настройка хотбара"), cx, y0 - 12, 0xFFFFFFFF);
        g.centeredText(this.font, t("Размер ячейки: " + HotbarConfig.cellSize + " px"), cx, y0 + 2, 0xFFFFFFFF);
        g.centeredText(this.font, t("X: " + HotbarConfig.offsetX + "   Y: " + HotbarConfig.offsetY), cx, y0 + 40, 0xFFFFFFFF);

        super.extractRenderState(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void removed() {
        HotbarConfig.save();
    }
}
