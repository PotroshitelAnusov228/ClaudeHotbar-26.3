package com.example.squarehotbar;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class SquareHotbarClient implements ClientModInitializer {
    public static final String MOD_ID = "squarehotbar";

    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        // Ванильный хотбар остаётся, квадратный рисуется сразу после него
        // (текст F3 и чат рисуются позже и остаются поверх).
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.HOTBAR,
                Identifier.fromNamespaceAndPath(MOD_ID, "square_hotbar"),
                (graphics, deltaTracker) -> HotbarRenderer.draw(graphics, Minecraft.getInstance())
        );

        // Поверх любых окон в игре (инвентарь, верстак, креатив, сундуки, меню и т.д.),
        // кроме собственного меню настройки: там хотбар и так виден вживую.
        // nextStratum() начинает новый верхний слой, чтобы ничего не затемняло и не перекрывало хотбар.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (client.level != null && !(screen instanceof HotbarConfigScreen)) {
                ScreenEvents.afterExtract(screen).register((s, graphics, mouseX, mouseY, tickDelta) -> {
                    graphics.nextStratum();
                    HotbarRenderer.draw(graphics, client);
                });
            }
        });

        // Клавиша меню настройки (по умолчанию H, переназначается в настройках управления)
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openMenuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.squarehotbar.menu",
                InputConstants.Type.KEYBOARD,
                InputConstants.KEY_H,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.level != null && client.gui.screen() == null) {
                    client.gui.setScreen(new HotbarConfigScreen());
                }
            }
        });
    }
}
