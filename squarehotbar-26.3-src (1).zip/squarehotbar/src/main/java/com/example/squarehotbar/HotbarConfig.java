package com.example.squarehotbar;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Настройки хотбара. Все значения в реальных пикселях экрана. */
public final class HotbarConfig {
    public static int cellSize = 105;
    public static int offsetX = 12;
    public static int offsetY = 0;
    public static int step = 1;

    private static final int MIN_SIZE = 20;
    private static final int MAX_SIZE = 600;

    static {
        load();
    }

    private HotbarConfig() {}

    public static void clamp() {
        if (cellSize < MIN_SIZE) cellSize = MIN_SIZE;
        if (cellSize > MAX_SIZE) cellSize = MAX_SIZE;
    }

    public static void reset() {
        cellSize = 105;
        offsetX = 12;
        offsetY = 0;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("squarehotbar.properties");
    }

    public static void load() {
        Path p = file();
        if (!Files.exists(p)) return;
        try (InputStream in = Files.newInputStream(p)) {
            Properties props = new Properties();
            props.load(in);
            cellSize = Integer.parseInt(props.getProperty("cellSize", String.valueOf(cellSize)));
            offsetX = Integer.parseInt(props.getProperty("offsetX", String.valueOf(offsetX)));
            offsetY = Integer.parseInt(props.getProperty("offsetY", String.valueOf(offsetY)));
            step = Integer.parseInt(props.getProperty("step", String.valueOf(step)));
            clamp();
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(file())) {
            Properties props = new Properties();
            props.setProperty("cellSize", String.valueOf(cellSize));
            props.setProperty("offsetX", String.valueOf(offsetX));
            props.setProperty("offsetY", String.valueOf(offsetY));
            props.setProperty("step", String.valueOf(step));
            props.store(out, "Square Hotbar");
        } catch (Exception ignored) {
        }
    }
}
