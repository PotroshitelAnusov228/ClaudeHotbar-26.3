package com.example.squarehotbar;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

/** Общая отрисовка квадратного хотбара: и для HUD, и для окон с ячейками. */
public final class HotbarRenderer {
    private static final int CELL = 22;
    private static final Identifier SELECTION = Identifier.withDefaultNamespace("hud/hotbar_selection");

    private HotbarRenderer() {}

    public static void draw(GuiGraphicsExtractor g, Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null) {
            return;
        }

        // Настройки в реальных пикселях -> GUI-единицы
        double gs = mc.getWindow().getGuiScale();
        float scale = (float) (HotbarConfig.cellSize / (CELL * gs));
        float x = (float) (HotbarConfig.offsetX / gs);
        float totalGui = (float) (3.0 * HotbarConfig.cellSize / gs);
        float y = (mc.getWindow().getGuiScaledHeight() - totalGui) / 2.0F + (float) (HotbarConfig.offsetY / gs);

        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);

        // 1) полупрозрачные слоты
        for (int i = 0; i < 9; i++) {
            int cx = (i % 3) * CELL;
            int cy = (i / 3) * CELL;
            g.fill(cx, cy, cx + CELL, cy + CELL, 0xB0202020);
            g.fill(cx + 1, cy + 1, cx + CELL - 1, cy + CELL - 1, 0x70000000);
        }

        // 2) ванильная обводка выбранного слота
        int selected = player.getInventory().getSelectedSlot();
        if (selected >= 0 && selected < 9) {
            int sx = (selected % 3) * CELL - 1;
            int sy = (selected / 3) * CELL - 1;
            g.blitSprite(RenderPipelines.GUI_TEXTURED, SELECTION, sx, sy, 24, 24);
        }

        // 3) предметы, количество, прочность
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            int ix = (i % 3) * CELL + 3;
            int iy = (i / 3) * CELL + 3;
            g.item(stack, ix, iy);
            g.itemDecorations(mc.font, stack, ix, iy);
        }

        g.pose().popMatrix();
    }
}
