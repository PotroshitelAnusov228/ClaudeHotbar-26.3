package com.example.squarehotbar.mixin;

import com.example.squarehotbar.HotbarRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Рисует квадратный хотбар поверх инвентаря, верстака, креатива и других окон с ячейками. */
@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void squarehotbar$draw(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        HotbarRenderer.draw(graphics, Minecraft.getInstance());
    }
}
