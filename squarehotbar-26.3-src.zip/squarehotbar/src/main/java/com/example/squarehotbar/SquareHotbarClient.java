package com.example.squarehotbar;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class SquareHotbarClient implements ClientModInitializer {
    public static final String MOD_ID = "squarehotbar";

    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        // Ванильный хотбар остаётся, квадратный рисуется сразу после него
        // (текст F3 и чат рисуются позже и остаются поверх).
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.HOTBAR,
                Identifier.fromNamespaceAndPath(MOD_ID, "square_hotbar"),
                (graphics, deltaTracker) -> HotbarRenderer.draw(graphics, Minecraft.getInstance())
        );

        // Клавиша меню настройки (по умолчанию H, переназначается в настройках управления)
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openMenuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.squarehotbar.menu",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_H,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.level != null && client.gui.screen() == null) {
                    client.gui.setScreen(new HotbarConfigScreen());
                }
            }
        });
    }
}
